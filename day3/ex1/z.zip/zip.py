#!/usr/bin/env python3

'''
Tass PythonAdvanced course
Solution to: Binary data: Zip
'''


import argparse
import struct, os

parser = argparse.ArgumentParser()
parser.add_argument('zipfile', type=argparse.FileType('rb'))
args = parser.parse_args()


class ZipHeader:
    '''Class representation for a Zip file header'''
    def __init__(self, data):
        assert len(data) == 11, "I'm expecting 11 elements of data"
        expected_sig = 0x04034b50
        assert data[0] == expected_sig, "I'm expecting local file header signature of {:X}, but got {:X}".format(expected_sig, data[0])

        self.version = data[1]
        self.general_purpose = data[2]
        self.compression_method = data[3]
        self.file_last_modification_time = data[4]
        self.file_last_modification_date = data[5]
        self.crc32 = data[6]
        self.compressed_size = data[7]
        self.uncompressed_size = data[8]
        self.file_name_length = data[9]
        self.extra_field_length = data[10]


f = args.zipfile # lazyness

while True:
    # We don't know in advance how many files are in a zipfile
    header = f.read(30)    
    unpacked_header = struct.unpack('<IHHHHHIIIHH', header) # little endian in zipfiles!

    if unpacked_header[0] == 0x02014b50:  # Stop when reaching the Central directory file header
        break
        
    zh = ZipHeader(unpacked_header)

    # read name and extra data
    name = f.read(zh.file_name_length)
    extra = f.read(zh.extra_field_length)
    f.seek(zh.compressed_size, os.SEEK_CUR)

    print("Found file {}; Compressed: {}; Uncompressed: {}".format(name, zh.uncompressed_size, zh.compressed_size))
    
